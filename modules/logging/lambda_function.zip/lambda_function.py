import json
import boto3
import os

sns = boto3.client('sns')

def handler(event, context):
    print(json.dumps(event))
    for record in event.get('Records', []):
        bucket  = record['s3']['bucket']['name']
        key     = record['s3']['object']['key']
        message = f"New CloudTrail log: s3://{bucket}/{key}"
        sns.publish(
            TopicArn=os.environ['SNS_TOPIC_ARN'],
            Subject="CloudTrail Log Delivered",
            Message=message,
        )
    return {'statusCode': 200}
